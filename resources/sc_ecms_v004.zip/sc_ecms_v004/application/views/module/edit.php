<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Module Edit</h3>
            </div>
			<?php echo form_open('module/edit/'.$module['idModule']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="ModuleName" class="control-label">ModuleName</label>
						<div class="form-group">
							<input type="text" name="ModuleName" value="<?php echo ($this->input->post('ModuleName') ? $this->input->post('ModuleName') : $module['ModuleName']); ?>" class="form-control" id="ModuleName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo ($this->input->post('CreatedDate') ? $this->input->post('CreatedDate') : $module['CreatedDate']); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo ($this->input->post('CreatedBy') ? $this->input->post('CreatedBy') : $module['CreatedBy']); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo ($this->input->post('ModifiedDate') ? $this->input->post('ModifiedDate') : $module['ModifiedDate']); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo ($this->input->post('ModifiedBy') ? $this->input->post('ModifiedBy') : $module['ModifiedBy']); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>