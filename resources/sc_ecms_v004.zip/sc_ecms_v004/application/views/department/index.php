<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Departments Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('department/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdDepartment</th>
						<th>DepartmentName</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($departments as $d){ ?>
                    <tr>
						<td><?php echo $d['idDepartment']; ?></td>
						<td><?php echo $d['DepartmentName']; ?></td>
						<td><?php echo $d['CreatedDate']; ?></td>
						<td><?php echo $d['CreatedBy']; ?></td>
						<td><?php echo $d['ModifiedDate']; ?></td>
						<td><?php echo $d['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('department/edit/'.$d['idDepartment']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('department/remove/'.$d['idDepartment']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
