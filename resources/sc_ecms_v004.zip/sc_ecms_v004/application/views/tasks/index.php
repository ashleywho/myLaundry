<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Tasks Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('tasks/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped  table-bordered table-hover">
                    <thead>
                    <tr>
						<th>IdTask</th>
						<th>TaskType</th>
						<th>TaskName</th>
						<th>TaskTag</th>
						<th>TaskRequlatoryAuth</th>
						<th>TaskRequested</th>
						<th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($tasks as $t){ ?>
                    <tr>
						<td><?php echo $t['idTask']; ?></td>
						<td><?php echo $t['TaskType']; ?></td>
						<td><?php echo $t['TaskName']; ?></td>
						<td><?php echo $t['TaskTag']; ?></td>
						<td><?php echo $t['TaskRequlatoryAuth']; ?></td>
						<td><?php echo $t['TaskRequested']; ?></td>
						<td>
                            <a href="<?php echo site_url('tasks/edit/'.$t['idTask']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('tasks/remove/'.$t['idTask']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    </tbody>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
