<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Tasks Add</h3>
            </div>
            <?php echo form_open('tasks/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="TaskType" class="control-label">Type</label>
						<div class="form-group">
							<select name="TaskType" class="form-control">
								<option value="">select type</option>
								<?php 
								foreach($all_types as $type)
								{
									$selected = ($type['idTypes'] == $this->input->post('TaskType')) ? ' selected="selected"' : "";

									echo '<option value="'.$type['idTypes'].'" '.$selected.'>'.$type['TypeName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="TaskName" class="control-label">TaskName</label>
						<div class="form-group">
							<input type="text" name="TaskName" value="<?php echo $this->input->post('TaskName'); ?>" class="form-control" id="TaskName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TaskTag" class="control-label">TaskTag</label>
						<div class="form-group">
							<input type="text" name="TaskTag" value="<?php echo $this->input->post('TaskTag'); ?>" class="form-control" id="TaskTag" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TaskRequlatoryAuth" class="control-label">TaskRequlatoryAuth</label>
						<div class="form-group">
							<input type="text" name="TaskRequlatoryAuth" value="<?php echo $this->input->post('TaskRequlatoryAuth'); ?>" class="form-control" id="TaskRequlatoryAuth" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TaskRequested" class="control-label">TaskRequested</label>
						<div class="form-group">
							<input type="text" name="TaskRequested" value="<?php echo $this->input->post('TaskRequested'); ?>" class="has-datetimepicker form-control" id="TaskRequested" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>