<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Filingoffence Add</h3>
            </div>
            <?php echo form_open('filingoffence/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="FilingOffenceOwner" class="control-label">User</label>
						<div class="form-group">
							<select name="FilingOffenceOwner" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $this->input->post('FilingOffenceOwner')) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOffenceSection" class="control-label">FilingOffenceSection</label>
						<div class="form-group">
							<input type="text" name="FilingOffenceSection" value="<?php echo $this->input->post('FilingOffenceSection'); ?>" class="form-control" id="FilingOffenceSection" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOffenceGroup" class="control-label">FilingOffenceGroup</label>
						<div class="form-group">
							<input type="text" name="FilingOffenceGroup" value="<?php echo $this->input->post('FilingOffenceGroup'); ?>" class="form-control" id="FilingOffenceGroup" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOffenceAct" class="control-label">FilingOffenceAct</label>
						<div class="form-group">
							<input type="text" name="FilingOffenceAct" value="<?php echo $this->input->post('FilingOffenceAct'); ?>" class="form-control" id="FilingOffenceAct" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOffenceNature" class="control-label">FilingOffenceNature</label>
						<div class="form-group">
							<input type="text" name="FilingOffenceNature" value="<?php echo $this->input->post('FilingOffenceNature'); ?>" class="form-control" id="FilingOffenceNature" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOffenceIsMainOffence" class="control-label">FilingOffenceIsMainOffence</label>
						<div class="form-group">
							<input type="text" name="FilingOffenceIsMainOffence" value="<?php echo $this->input->post('FilingOffenceIsMainOffence'); ?>" class="form-control" id="FilingOffenceIsMainOffence" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOffenceDesc" class="control-label">FilingOffenceDesc</label>
						<div class="form-group">
							<textarea name="FilingOffenceDesc" class="form-control" id="FilingOffenceDesc"><?php echo $this->input->post('FilingOffenceDesc'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>