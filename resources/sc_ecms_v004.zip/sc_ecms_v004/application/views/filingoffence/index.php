<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Filingoffences Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('filingoffence/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdFilingOffence</th>
						<th>FilingOffenceOwner</th>
						<th>FilingOffenceSection</th>
						<th>FilingOffenceGroup</th>
						<th>FilingOffenceAct</th>
						<th>FilingOffenceNature</th>
						<th>FilingOffenceIsMainOffence</th>
						<th>FilingOffenceDesc</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($filingoffences as $f){ ?>
                    <tr>
						<td><?php echo $f['idFilingOffence']; ?></td>
						<td><?php echo $f['FilingOffenceOwner']; ?></td>
						<td><?php echo $f['FilingOffenceSection']; ?></td>
						<td><?php echo $f['FilingOffenceGroup']; ?></td>
						<td><?php echo $f['FilingOffenceAct']; ?></td>
						<td><?php echo $f['FilingOffenceNature']; ?></td>
						<td><?php echo $f['FilingOffenceIsMainOffence']; ?></td>
						<td><?php echo $f['FilingOffenceDesc']; ?></td>
						<td>
                            <a href="<?php echo site_url('filingoffence/edit/'.$f['idFilingOffence']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('filingoffence/remove/'.$f['idFilingOffence']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
