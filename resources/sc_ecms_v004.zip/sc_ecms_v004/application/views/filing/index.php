<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Filings Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('filing/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdFiling</th>
						<th>FilingType</th>
						<th>FilingNo</th>
						<th>FilingFileName</th>
						<th>FilingReferalForm</th>
						<th>FilingOriNo</th>
						<th>FilingRemarks</th>
						<th>FilingOfficialCloseDate</th>
						<th>FilingASUCloseDate</th>
						<th>FilingApprovePosition</th>
						<th>FilingCurrentStatus</th>
						<th>FilingNotes</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>FilingDateFileOpened</th>
						<th>FilingYearOffence</th>
						<th>FilingOriFileType</th>
						<th>FilingTotFile</th>
						<th>FilingConvertedTo</th>
						<th>FilingBriefFact</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($filings as $f){ ?>
                    <tr>
						<td><?php echo $f['idFiling']; ?></td>
						<td><?php echo $f['FilingType']; ?></td>
						<td><?php echo $f['FilingNo']; ?></td>
						<td><?php echo $f['FilingFileName']; ?></td>
						<td><?php echo $f['FilingReferalForm']; ?></td>
						<td><?php echo $f['FilingOriNo']; ?></td>
						<td><?php echo $f['FilingRemarks']; ?></td>
						<td><?php echo $f['FilingOfficialCloseDate']; ?></td>
						<td><?php echo $f['FilingASUCloseDate']; ?></td>
						<td><?php echo $f['FilingApprovePosition']; ?></td>
						<td><?php echo $f['FilingCurrentStatus']; ?></td>
						<td><?php echo $f['FilingNotes']; ?></td>
						<td><?php echo $f['CreatedDate']; ?></td>
						<td><?php echo $f['CreatedBy']; ?></td>
						<td><?php echo $f['ModifiedDate']; ?></td>
						<td><?php echo $f['ModifiedBy']; ?></td>
						<td><?php echo $f['FilingDateFileOpened']; ?></td>
						<td><?php echo $f['FilingYearOffence']; ?></td>
						<td><?php echo $f['FilingOriFileType']; ?></td>
						<td><?php echo $f['FilingTotFile']; ?></td>
						<td><?php echo $f['FilingConvertedTo']; ?></td>
						<td><?php echo $f['FilingBriefFact']; ?></td>
						<td>
                            <a href="<?php echo site_url('filing/edit/'.$f['idFiling']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('filing/remove/'.$f['idFiling']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
