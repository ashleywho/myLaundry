<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Filing Edit</h3>
            </div>
			<?php echo form_open('filing/edit/'.$filing['idFiling']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="FilingType" class="control-label">FilingType</label>
						<div class="form-group">
							<input type="text" name="FilingType" value="<?php echo ($this->input->post('FilingType') ? $this->input->post('FilingType') : $filing['FilingType']); ?>" class="form-control" id="FilingType" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingNo" class="control-label">FilingNo</label>
						<div class="form-group">
							<input type="text" name="FilingNo" value="<?php echo ($this->input->post('FilingNo') ? $this->input->post('FilingNo') : $filing['FilingNo']); ?>" class="form-control" id="FilingNo" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingFileName" class="control-label">FilingFileName</label>
						<div class="form-group">
							<input type="text" name="FilingFileName" value="<?php echo ($this->input->post('FilingFileName') ? $this->input->post('FilingFileName') : $filing['FilingFileName']); ?>" class="form-control" id="FilingFileName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingReferalForm" class="control-label">FilingReferalForm</label>
						<div class="form-group">
							<input type="text" name="FilingReferalForm" value="<?php echo ($this->input->post('FilingReferalForm') ? $this->input->post('FilingReferalForm') : $filing['FilingReferalForm']); ?>" class="form-control" id="FilingReferalForm" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOriNo" class="control-label">FilingOriNo</label>
						<div class="form-group">
							<input type="text" name="FilingOriNo" value="<?php echo ($this->input->post('FilingOriNo') ? $this->input->post('FilingOriNo') : $filing['FilingOriNo']); ?>" class="form-control" id="FilingOriNo" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingRemarks" class="control-label">FilingRemarks</label>
						<div class="form-group">
							<input type="text" name="FilingRemarks" value="<?php echo ($this->input->post('FilingRemarks') ? $this->input->post('FilingRemarks') : $filing['FilingRemarks']); ?>" class="form-control" id="FilingRemarks" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOfficialCloseDate" class="control-label">FilingOfficialCloseDate</label>
						<div class="form-group">
							<input type="text" name="FilingOfficialCloseDate" value="<?php echo ($this->input->post('FilingOfficialCloseDate') ? $this->input->post('FilingOfficialCloseDate') : $filing['FilingOfficialCloseDate']); ?>" class="has-datetimepicker form-control" id="FilingOfficialCloseDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingASUCloseDate" class="control-label">FilingASUCloseDate</label>
						<div class="form-group">
							<input type="text" name="FilingASUCloseDate" value="<?php echo ($this->input->post('FilingASUCloseDate') ? $this->input->post('FilingASUCloseDate') : $filing['FilingASUCloseDate']); ?>" class="has-datetimepicker form-control" id="FilingASUCloseDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingApprovePosition" class="control-label">FilingApprovePosition</label>
						<div class="form-group">
							<input type="text" name="FilingApprovePosition" value="<?php echo ($this->input->post('FilingApprovePosition') ? $this->input->post('FilingApprovePosition') : $filing['FilingApprovePosition']); ?>" class="form-control" id="FilingApprovePosition" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingCurrentStatus" class="control-label">FilingCurrentStatus</label>
						<div class="form-group">
							<input type="text" name="FilingCurrentStatus" value="<?php echo ($this->input->post('FilingCurrentStatus') ? $this->input->post('FilingCurrentStatus') : $filing['FilingCurrentStatus']); ?>" class="form-control" id="FilingCurrentStatus" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingNotes" class="control-label">FilingNotes</label>
						<div class="form-group">
							<input type="text" name="FilingNotes" value="<?php echo ($this->input->post('FilingNotes') ? $this->input->post('FilingNotes') : $filing['FilingNotes']); ?>" class="form-control" id="FilingNotes" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo ($this->input->post('CreatedDate') ? $this->input->post('CreatedDate') : $filing['CreatedDate']); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo ($this->input->post('CreatedBy') ? $this->input->post('CreatedBy') : $filing['CreatedBy']); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo ($this->input->post('ModifiedDate') ? $this->input->post('ModifiedDate') : $filing['ModifiedDate']); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo ($this->input->post('ModifiedBy') ? $this->input->post('ModifiedBy') : $filing['ModifiedBy']); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingDateFileOpened" class="control-label">FilingDateFileOpened</label>
						<div class="form-group">
							<input type="text" name="FilingDateFileOpened" value="<?php echo ($this->input->post('FilingDateFileOpened') ? $this->input->post('FilingDateFileOpened') : $filing['FilingDateFileOpened']); ?>" class="has-datetimepicker form-control" id="FilingDateFileOpened" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingYearOffence" class="control-label">FilingYearOffence</label>
						<div class="form-group">
							<input type="text" name="FilingYearOffence" value="<?php echo ($this->input->post('FilingYearOffence') ? $this->input->post('FilingYearOffence') : $filing['FilingYearOffence']); ?>" class="form-control" id="FilingYearOffence" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingOriFileType" class="control-label">FilingOriFileType</label>
						<div class="form-group">
							<input type="text" name="FilingOriFileType" value="<?php echo ($this->input->post('FilingOriFileType') ? $this->input->post('FilingOriFileType') : $filing['FilingOriFileType']); ?>" class="form-control" id="FilingOriFileType" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingTotFile" class="control-label">FilingTotFile</label>
						<div class="form-group">
							<input type="text" name="FilingTotFile" value="<?php echo ($this->input->post('FilingTotFile') ? $this->input->post('FilingTotFile') : $filing['FilingTotFile']); ?>" class="form-control" id="FilingTotFile" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingConvertedTo" class="control-label">FilingConvertedTo</label>
						<div class="form-group">
							<input type="text" name="FilingConvertedTo" value="<?php echo ($this->input->post('FilingConvertedTo') ? $this->input->post('FilingConvertedTo') : $filing['FilingConvertedTo']); ?>" class="form-control" id="FilingConvertedTo" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingBriefFact" class="control-label">FilingBriefFact</label>
						<div class="form-group">
							<textarea name="FilingBriefFact" class="form-control" id="FilingBriefFact"><?php echo ($this->input->post('FilingBriefFact') ? $this->input->post('FilingBriefFact') : $filing['FilingBriefFact']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>