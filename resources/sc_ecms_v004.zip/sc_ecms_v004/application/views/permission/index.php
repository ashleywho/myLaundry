<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Permissions Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('permission/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdPermission</th>
						<th>PermissionName</th>
						<th>PermissionController</th>
						<th>PermissionFunction</th>
						<th>PermissionIsDeleted</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>PermissionAccess</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($permissions as $p){ ?>
                    <tr>
						<td><?php echo $p['idPermission']; ?></td>
						<td><?php echo $p['PermissionName']; ?></td>
						<td><?php echo $p['PermissionController']; ?></td>
						<td><?php echo $p['PermissionFunction']; ?></td>
						<td><?php echo $p['PermissionIsDeleted']; ?></td>
						<td><?php echo $p['CreatedDate']; ?></td>
						<td><?php echo $p['CreatedBy']; ?></td>
						<td><?php echo $p['ModifiedDate']; ?></td>
						<td><?php echo $p['ModifiedBy']; ?></td>
						<td><?php echo $p['PermissionAccess']; ?></td>
						<td>
                            <a href="<?php echo site_url('permission/edit/'.$p['idPermission']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('permission/remove/'.$p['idPermission']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
