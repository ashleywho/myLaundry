<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Permission Add</h3>
            </div>
            <?php echo form_open('permission/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="PermissionName" class="control-label">PermissionName</label>
						<div class="form-group">
							<input type="text" name="PermissionName" value="<?php echo $this->input->post('PermissionName'); ?>" class="form-control" id="PermissionName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="PermissionController" class="control-label">PermissionController</label>
						<div class="form-group">
							<input type="text" name="PermissionController" value="<?php echo $this->input->post('PermissionController'); ?>" class="form-control" id="PermissionController" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="PermissionFunction" class="control-label">PermissionFunction</label>
						<div class="form-group">
							<input type="text" name="PermissionFunction" value="<?php echo $this->input->post('PermissionFunction'); ?>" class="form-control" id="PermissionFunction" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="PermissionIsDeleted" class="control-label">PermissionIsDeleted</label>
						<div class="form-group">
							<input type="text" name="PermissionIsDeleted" value="<?php echo $this->input->post('PermissionIsDeleted'); ?>" class="has-datetimepicker form-control" id="PermissionIsDeleted" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo $this->input->post('CreatedDate'); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo $this->input->post('CreatedBy'); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo $this->input->post('ModifiedDate'); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo $this->input->post('ModifiedBy'); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="PermissionAccess" class="control-label">PermissionAccess</label>
						<div class="form-group">
							<textarea name="PermissionAccess" class="form-control" id="PermissionAccess"><?php echo $this->input->post('PermissionAccess'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>