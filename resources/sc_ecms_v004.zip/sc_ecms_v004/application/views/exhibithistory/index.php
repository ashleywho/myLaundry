<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Exhibithistory Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('exhibithistory/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdExhibitHistory</th>
						<th>ExhibitType</th>
						<th>IdExhibit</th>
						<th>ExhibitLocation</th>
						<th>ExhibitCurrentMovement</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($exhibithistory as $e){ ?>
                    <tr>
						<td><?php echo $e['idExhibitHistory']; ?></td>
						<td><?php echo $e['ExhibitType']; ?></td>
						<td><?php echo $e['idExhibit']; ?></td>
						<td><?php echo $e['ExhibitLocation']; ?></td>
						<td><?php echo $e['ExhibitCurrentMovement']; ?></td>
						<td><?php echo $e['CreatedDate']; ?></td>
						<td><?php echo $e['CreatedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('exhibithistory/edit/'.$e['idExhibitHistory']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('exhibithistory/remove/'.$e['idExhibitHistory']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
