<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Exhibithistory Add</h3>
            </div>
            <?php echo form_open('exhibithistory/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="ExhibitType" class="control-label">Type</label>
						<div class="form-group">
							<select name="ExhibitType" class="form-control">
								<option value="">select type</option>
								<?php 
								foreach($all_types as $type)
								{
									$selected = ($type['idTypes'] == $this->input->post('ExhibitType')) ? ' selected="selected"' : "";

									echo '<option value="'.$type['idTypes'].'" '.$selected.'>'.$type['TypeName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="idExhibit" class="control-label">IdExhibit</label>
						<div class="form-group">
							<input type="text" name="idExhibit" value="<?php echo $this->input->post('idExhibit'); ?>" class="form-control" id="idExhibit" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ExhibitLocation" class="control-label">ExhibitLocation</label>
						<div class="form-group">
							<input type="text" name="ExhibitLocation" value="<?php echo $this->input->post('ExhibitLocation'); ?>" class="form-control" id="ExhibitLocation" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ExhibitCurrentMovement" class="control-label">ExhibitCurrentMovement</label>
						<div class="form-group">
							<input type="text" name="ExhibitCurrentMovement" value="<?php echo $this->input->post('ExhibitCurrentMovement'); ?>" class="form-control" id="ExhibitCurrentMovement" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo $this->input->post('CreatedDate'); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo $this->input->post('CreatedBy'); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>