<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Teammember Edit</h3>
            </div>
			<?php echo form_open('teammember/edit/'.$teammember['idTeamMember']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="idTeam" class="control-label">Team</label>
						<div class="form-group">
							<select name="idTeam" class="form-control">
								<option value="">select team</option>
								<?php 
								foreach($all_teams as $team)
								{
									$selected = ($team['idTeam'] == $teammember['idTeam']) ? ' selected="selected"' : "";

									echo '<option value="'.$team['idTeam'].'" '.$selected.'>'.$team['TeamName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="idUser" class="control-label">User</label>
						<div class="form-group">
							<select name="idUser" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $teammember['idUser']) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="TeamMemberStatus" class="control-label">TeamMemberStatus</label>
						<div class="form-group">
							<input type="text" name="TeamMemberStatus" value="<?php echo ($this->input->post('TeamMemberStatus') ? $this->input->post('TeamMemberStatus') : $teammember['TeamMemberStatus']); ?>" class="form-control" id="TeamMemberStatus" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TeamMemberRole" class="control-label">TeamMemberRole</label>
						<div class="form-group">
							<input type="text" name="TeamMemberRole" value="<?php echo ($this->input->post('TeamMemberRole') ? $this->input->post('TeamMemberRole') : $teammember['TeamMemberRole']); ?>" class="form-control" id="TeamMemberRole" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TeamMemberStartDate" class="control-label">TeamMemberStartDate</label>
						<div class="form-group">
							<input type="text" name="TeamMemberStartDate" value="<?php echo ($this->input->post('TeamMemberStartDate') ? $this->input->post('TeamMemberStartDate') : $teammember['TeamMemberStartDate']); ?>" class="has-datepicker form-control" id="TeamMemberStartDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TeamMemberEndDate" class="control-label">TeamMemberEndDate</label>
						<div class="form-group">
							<input type="text" name="TeamMemberEndDate" value="<?php echo ($this->input->post('TeamMemberEndDate') ? $this->input->post('TeamMemberEndDate') : $teammember['TeamMemberEndDate']); ?>" class="has-datepicker form-control" id="TeamMemberEndDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo ($this->input->post('CreatedDate') ? $this->input->post('CreatedDate') : $teammember['CreatedDate']); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo ($this->input->post('CreatedBy') ? $this->input->post('CreatedBy') : $teammember['CreatedBy']); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo ($this->input->post('ModifiedDate') ? $this->input->post('ModifiedDate') : $teammember['ModifiedDate']); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo ($this->input->post('ModifiedBy') ? $this->input->post('ModifiedBy') : $teammember['ModifiedBy']); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>