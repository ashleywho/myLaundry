<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Teammembers Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('teammember/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdTeamMember</th>
						<th>IdTeam</th>
						<th>IdUser</th>
						<th>TeamMemberStatus</th>
						<th>TeamMemberRole</th>
						<th>TeamMemberStartDate</th>
						<th>TeamMemberEndDate</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($teammembers as $t){ ?>
                    <tr>
						<td><?php echo $t['idTeamMember']; ?></td>
						<td><?php echo $t['idTeam']; ?></td>
						<td><?php echo $t['idUser']; ?></td>
						<td><?php echo $t['TeamMemberStatus']; ?></td>
						<td><?php echo $t['TeamMemberRole']; ?></td>
						<td><?php echo $t['TeamMemberStartDate']; ?></td>
						<td><?php echo $t['TeamMemberEndDate']; ?></td>
						<td><?php echo $t['CreatedDate']; ?></td>
						<td><?php echo $t['CreatedBy']; ?></td>
						<td><?php echo $t['ModifiedDate']; ?></td>
						<td><?php echo $t['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('teammember/edit/'.$t['idTeamMember']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('teammember/remove/'.$t['idTeamMember']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
