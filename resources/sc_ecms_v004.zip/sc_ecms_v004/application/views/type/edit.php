<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Type Edit</h3>
            </div>
			<?php echo form_open('type/edit/'.$type['idTypes']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="idModule" class="control-label">Module</label>
						<div class="form-group">
							<select name="idModule" class="form-control">
								<option value="">select module</option>
								<?php 
								foreach($all_modules as $module)
								{
									$selected = ($module['idModule'] == $type['idModule']) ? ' selected="selected"' : "";

									echo '<option value="'.$module['idModule'].'" '.$selected.'>'.$module['ModuleName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="TypeName" class="control-label">TypeName</label>
						<div class="form-group">
							<input type="text" name="TypeName" value="<?php echo ($this->input->post('TypeName') ? $this->input->post('TypeName') : $type['TypeName']); ?>" class="form-control" id="TypeName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="isActive" class="control-label">IsActive</label>
						<div class="form-group">
							<input type="text" name="isActive" value="<?php echo ($this->input->post('isActive') ? $this->input->post('isActive') : $type['isActive']); ?>" class="form-control" id="isActive" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>