<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Menu Add</h3>
            </div>
            <?php echo form_open('menu/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="MenuParent" class="control-label">Module</label>
						<div class="form-group">
							<select name="MenuParent" class="form-control">
								<option value="">select module</option>
								<?php 
								foreach($all_modules as $module)
								{
									$selected = ($module['idModule'] == $this->input->post('MenuParent')) ? ' selected="selected"' : "";

									echo '<option value="'.$module['idModule'].'" '.$selected.'>'.$module['ModuleName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="MenuName" class="control-label">MenuName</label>
						<div class="form-group">
							<input type="text" name="MenuName" value="<?php echo $this->input->post('MenuName'); ?>" class="form-control" id="MenuName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="MenuUrl" class="control-label">MenuUrl</label>
						<div class="form-group">
							<input type="text" name="MenuUrl" value="<?php echo $this->input->post('MenuUrl'); ?>" class="form-control" id="MenuUrl" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="MenuOrder" class="control-label">MenuOrder</label>
						<div class="form-group">
							<input type="text" name="MenuOrder" value="<?php echo $this->input->post('MenuOrder'); ?>" class="form-control" id="MenuOrder" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="MenuIcon" class="control-label">MenuIcon</label>
						<div class="form-group">
							<input type="text" name="MenuIcon" value="<?php echo $this->input->post('MenuIcon'); ?>" class="form-control" id="MenuIcon" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="MenuPlaceholder" class="control-label">MenuPlaceholder</label>
						<div class="form-group">
							<input type="text" name="MenuPlaceholder" value="<?php echo $this->input->post('MenuPlaceholder'); ?>" class="form-control" id="MenuPlaceholder" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>