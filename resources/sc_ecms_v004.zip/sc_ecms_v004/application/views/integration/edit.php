<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Integration Edit</h3>
            </div>
			<?php echo form_open('integration/edit/'.$integration['idIntegration']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="IntegrationName" class="control-label">IntegrationName</label>
						<div class="form-group">
							<input type="text" name="IntegrationName" value="<?php echo ($this->input->post('IntegrationName') ? $this->input->post('IntegrationName') : $integration['IntegrationName']); ?>" class="form-control" id="IntegrationName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationType" class="control-label">IntegrationType</label>
						<div class="form-group">
							<input type="text" name="IntegrationType" value="<?php echo ($this->input->post('IntegrationType') ? $this->input->post('IntegrationType') : $integration['IntegrationType']); ?>" class="form-control" id="IntegrationType" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationURL" class="control-label">IntegrationURL</label>
						<div class="form-group">
							<input type="text" name="IntegrationURL" value="<?php echo ($this->input->post('IntegrationURL') ? $this->input->post('IntegrationURL') : $integration['IntegrationURL']); ?>" class="form-control" id="IntegrationURL" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationLogin" class="control-label">IntegrationLogin</label>
						<div class="form-group">
							<input type="text" name="IntegrationLogin" value="<?php echo ($this->input->post('IntegrationLogin') ? $this->input->post('IntegrationLogin') : $integration['IntegrationLogin']); ?>" class="form-control" id="IntegrationLogin" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationPassword" class="control-label">IntegrationPassword</label>
						<div class="form-group">
							<input type="text" name="IntegrationPassword" value="<?php echo ($this->input->post('IntegrationPassword') ? $this->input->post('IntegrationPassword') : $integration['IntegrationPassword']); ?>" class="form-control" id="IntegrationPassword" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationIsLDAP" class="control-label">IntegrationIsLDAP</label>
						<div class="form-group">
							<input type="text" name="IntegrationIsLDAP" value="<?php echo ($this->input->post('IntegrationIsLDAP') ? $this->input->post('IntegrationIsLDAP') : $integration['IntegrationIsLDAP']); ?>" class="form-control" id="IntegrationIsLDAP" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationDescription" class="control-label">IntegrationDescription</label>
						<div class="form-group">
							<input type="text" name="IntegrationDescription" value="<?php echo ($this->input->post('IntegrationDescription') ? $this->input->post('IntegrationDescription') : $integration['IntegrationDescription']); ?>" class="form-control" id="IntegrationDescription" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationResult" class="control-label">IntegrationResult</label>
						<div class="form-group">
							<textarea name="IntegrationResult" class="form-control" id="IntegrationResult"><?php echo ($this->input->post('IntegrationResult') ? $this->input->post('IntegrationResult') : $integration['IntegrationResult']); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationParameter" class="control-label">IntegrationParameter</label>
						<div class="form-group">
							<textarea name="IntegrationParameter" class="form-control" id="IntegrationParameter"><?php echo ($this->input->post('IntegrationParameter') ? $this->input->post('IntegrationParameter') : $integration['IntegrationParameter']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>