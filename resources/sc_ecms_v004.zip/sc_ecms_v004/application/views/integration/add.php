<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Integration Add</h3>
            </div>
            <?php echo form_open('integration/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="IntegrationName" class="control-label">IntegrationName</label>
						<div class="form-group">
							<input type="text" name="IntegrationName" value="<?php echo $this->input->post('IntegrationName'); ?>" class="form-control" id="IntegrationName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationType" class="control-label">IntegrationType</label>
						<div class="form-group">
							<input type="text" name="IntegrationType" value="<?php echo $this->input->post('IntegrationType'); ?>" class="form-control" id="IntegrationType" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationURL" class="control-label">IntegrationURL</label>
						<div class="form-group">
							<input type="text" name="IntegrationURL" value="<?php echo $this->input->post('IntegrationURL'); ?>" class="form-control" id="IntegrationURL" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationLogin" class="control-label">IntegrationLogin</label>
						<div class="form-group">
							<input type="text" name="IntegrationLogin" value="<?php echo $this->input->post('IntegrationLogin'); ?>" class="form-control" id="IntegrationLogin" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationPassword" class="control-label">IntegrationPassword</label>
						<div class="form-group">
							<input type="text" name="IntegrationPassword" value="<?php echo $this->input->post('IntegrationPassword'); ?>" class="form-control" id="IntegrationPassword" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationIsLDAP" class="control-label">IntegrationIsLDAP</label>
						<div class="form-group">
							<input type="text" name="IntegrationIsLDAP" value="<?php echo $this->input->post('IntegrationIsLDAP'); ?>" class="form-control" id="IntegrationIsLDAP" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationDescription" class="control-label">IntegrationDescription</label>
						<div class="form-group">
							<input type="text" name="IntegrationDescription" value="<?php echo $this->input->post('IntegrationDescription'); ?>" class="form-control" id="IntegrationDescription" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationResult" class="control-label">IntegrationResult</label>
						<div class="form-group">
							<textarea name="IntegrationResult" class="form-control" id="IntegrationResult"><?php echo $this->input->post('IntegrationResult'); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="IntegrationParameter" class="control-label">IntegrationParameter</label>
						<div class="form-group">
							<textarea name="IntegrationParameter" class="form-control" id="IntegrationParameter"><?php echo $this->input->post('IntegrationParameter'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>