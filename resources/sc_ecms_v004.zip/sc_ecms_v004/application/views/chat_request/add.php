<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Chat Request Add</h3>
            </div>
            <?php echo form_open('chat_request/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="sender_id" class="control-label">User</label>
						<div class="form-group">
							<select name="sender_id" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $this->input->post('sender_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="receiver_id" class="control-label">User</label>
						<div class="form-group">
							<select name="receiver_id" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $this->input->post('receiver_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="chat_request_status" class="control-label">Chat Request Status</label>
						<div class="form-group">
							<input type="text" name="chat_request_status" value="<?php echo $this->input->post('chat_request_status'); ?>" class="form-control" id="chat_request_status" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>