<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Chat Request Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('chat_request/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Chat Request Id</th>
						<th>Sender Id</th>
						<th>Receiver Id</th>
						<th>Chat Request Status</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($chat_request as $c){ ?>
                    <tr>
						<td><?php echo $c['chat_request_id']; ?></td>
						<td><?php echo $c['sender_id']; ?></td>
						<td><?php echo $c['receiver_id']; ?></td>
						<td><?php echo $c['chat_request_status']; ?></td>
						<td>
                            <a href="<?php echo site_url('chat_request/edit/'.$c['chat_request_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('chat_request/remove/'.$c['chat_request_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
