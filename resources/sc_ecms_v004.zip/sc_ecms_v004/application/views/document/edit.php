<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Document Edit</h3>
            </div>
			<?php echo form_open('document/edit/'.$document['idDocument']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="idModule" class="control-label">Module</label>
						<div class="form-group">
							<select name="idModule" class="form-control">
								<option value="">select module</option>
								<?php 
								foreach($all_modules as $module)
								{
									$selected = ($module['idModule'] == $document['idModule']) ? ' selected="selected"' : "";

									echo '<option value="'.$module['idModule'].'" '.$selected.'>'.$module['ModuleName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="UploadFolder" class="control-label">UploadFolder</label>
						<div class="form-group">
							<input type="text" name="UploadFolder" value="<?php echo ($this->input->post('UploadFolder') ? $this->input->post('UploadFolder') : $document['UploadFolder']); ?>" class="form-control" id="UploadFolder" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="UploadFilename" class="control-label">UploadFilename</label>
						<div class="form-group">
							<input type="text" name="UploadFilename" value="<?php echo ($this->input->post('UploadFilename') ? $this->input->post('UploadFilename') : $document['UploadFilename']); ?>" class="form-control" id="UploadFilename" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="UploadExt" class="control-label">UploadExt</label>
						<div class="form-group">
							<input type="text" name="UploadExt" value="<?php echo ($this->input->post('UploadExt') ? $this->input->post('UploadExt') : $document['UploadExt']); ?>" class="form-control" id="UploadExt" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="UploadOriginalName" class="control-label">UploadOriginalName</label>
						<div class="form-group">
							<input type="text" name="UploadOriginalName" value="<?php echo ($this->input->post('UploadOriginalName') ? $this->input->post('UploadOriginalName') : $document['UploadOriginalName']); ?>" class="form-control" id="UploadOriginalName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="idLink" class="control-label">IdLink</label>
						<div class="form-group">
							<input type="text" name="idLink" value="<?php echo ($this->input->post('idLink') ? $this->input->post('idLink') : $document['idLink']); ?>" class="form-control" id="idLink" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="wordworld" class="control-label">Wordworld</label>
						<div class="form-group">
							<textarea name="wordworld" class="form-control" id="wordworld"><?php echo ($this->input->post('wordworld') ? $this->input->post('wordworld') : $document['wordworld']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>