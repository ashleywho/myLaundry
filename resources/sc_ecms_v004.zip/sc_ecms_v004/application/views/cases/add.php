<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Cases Add</h3>
            </div>
            <?php echo form_open('cases/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="CaseStatus" class="control-label">Casestatu</label>
						<div class="form-group">
							<select name="CaseStatus" class="form-control">
								<option value="">select casestatu</option>
								<?php 
								foreach($all_casestatus as $casestatu)
								{
									$selected = ($casestatu['CaseStatus_id'] == $this->input->post('CaseStatus')) ? ' selected="selected"' : "";

									echo '<option value="'.$casestatu['CaseStatus_id'].'" '.$selected.'>'.$casestatu['CaseStatusName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseCategory" class="control-label">Casecategory</label>
						<div class="form-group">
							<select name="CaseCategory" class="form-control">
								<option value="">select casecategory</option>
								<?php 
								foreach($all_casecategory as $casecategory)
								{
									$selected = ($casecategory['CaseCategory_id'] == $this->input->post('CaseCategory')) ? ' selected="selected"' : "";

									echo '<option value="'.$casecategory['CaseCategory_id'].'" '.$selected.'>'.$casecategory['CaseCategoryName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseType" class="control-label">Casetype</label>
						<div class="form-group">
							<select name="CaseType" class="form-control">
								<option value="">select casetype</option>
								<?php 
								foreach($all_casetype as $casetype)
								{
									$selected = ($casetype['CaseType_id'] == $this->input->post('CaseType')) ? ' selected="selected"' : "";

									echo '<option value="'.$casetype['CaseType_id'].'" '.$selected.'>'.$casetype['CaseTypeName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseName" class="control-label">CaseName</label>
						<div class="form-group">
							<input type="text" name="CaseName" value="<?php echo $this->input->post('CaseName'); ?>" class="form-control" id="CaseName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseDescription" class="control-label">CaseDescription</label>
						<div class="form-group">
							<input type="text" name="CaseDescription" value="<?php echo $this->input->post('CaseDescription'); ?>" class="form-control" id="CaseDescription" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo $this->input->post('CreatedDate'); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo $this->input->post('CreatedBy'); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo $this->input->post('ModifiedDate'); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo $this->input->post('ModifiedBy'); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>