<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Exhibits Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('exhibit/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdExhibit</th>
						<th>ExhibitType</th>
						<th>ExhibitName</th>
						<th>ExhibitLocation</th>
						<th>ExhibitCurrentMovement</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($exhibits as $e){ ?>
                    <tr>
						<td><?php echo $e['idExhibit']; ?></td>
						<td><?php echo $e['ExhibitType']; ?></td>
						<td><?php echo $e['ExhibitName']; ?></td>
						<td><?php echo $e['ExhibitLocation']; ?></td>
						<td><?php echo $e['ExhibitCurrentMovement']; ?></td>
						<td><?php echo $e['CreatedDate']; ?></td>
						<td><?php echo $e['CreatedBy']; ?></td>
						<td><?php echo $e['ModifiedDate']; ?></td>
						<td><?php echo $e['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('exhibit/edit/'.$e['idExhibit']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('exhibit/remove/'.$e['idExhibit']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
