<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Filinginfos Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('filinginfo/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdFilingInfo</th>
						<th>IdFiling</th>
						<th>FilingInfoType</th>
						<th>FilingInfoOwner</th>
						<th>FilingInfoOYDS</th>
						<th>FilingInfoDesignation</th>
						<th>FilingInfoRemarks</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($filinginfos as $f){ ?>
                    <tr>
						<td><?php echo $f['idFilingInfo']; ?></td>
						<td><?php echo $f['idFiling']; ?></td>
						<td><?php echo $f['FilingInfoType']; ?></td>
						<td><?php echo $f['FilingInfoOwner']; ?></td>
						<td><?php echo $f['FilingInfoOYDS']; ?></td>
						<td><?php echo $f['FilingInfoDesignation']; ?></td>
						<td><?php echo $f['FilingInfoRemarks']; ?></td>
						<td><?php echo $f['CreatedDate']; ?></td>
						<td><?php echo $f['CreatedBy']; ?></td>
						<td><?php echo $f['ModifiedDate']; ?></td>
						<td><?php echo $f['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('filinginfo/edit/'.$f['idFilingInfo']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('filinginfo/remove/'.$f['idFilingInfo']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
