<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Caseassignments Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('caseassignment/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdCaseAssignment</th>
						<th>CaseAssignmentName</th>
						<th>CaseAssignmentDesc</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($caseassignments as $c){ ?>
                    <tr>
						<td><?php echo $c['idCaseAssignment']; ?></td>
						<td><?php echo $c['CaseAssignmentName']; ?></td>
						<td><?php echo $c['CaseAssignmentDesc']; ?></td>
						<td><?php echo $c['CreatedDate']; ?></td>
						<td><?php echo $c['CreatedBy']; ?></td>
						<td><?php echo $c['ModifiedDate']; ?></td>
						<td><?php echo $c['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('caseassignment/edit/'.$c['idCaseAssignment']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('caseassignment/remove/'.$c['idCaseAssignment']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
