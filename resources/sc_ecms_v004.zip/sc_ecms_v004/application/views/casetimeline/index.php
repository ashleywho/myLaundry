<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Casetimelines Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('casetimeline/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdCaseTimelines</th>
						<th>IdCase</th>
						<th>CaseTimelineIsDeleted</th>
						<th>CaseTimelineStatus</th>
						<th>CaseTimelineDescription</th>
						<th>CaseTimelineRemarks</th>
						<th>CaseTimelineTag</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($casetimelines as $c){ ?>
                    <tr>
						<td><?php echo $c['idCaseTimelines']; ?></td>
						<td><?php echo $c['idCase']; ?></td>
						<td><?php echo $c['CaseTimelineIsDeleted']; ?></td>
						<td><?php echo $c['CaseTimelineStatus']; ?></td>
						<td><?php echo $c['CaseTimelineDescription']; ?></td>
						<td><?php echo $c['CaseTimelineRemarks']; ?></td>
						<td><?php echo $c['CaseTimelineTag']; ?></td>
						<td><?php echo $c['CreatedDate']; ?></td>
						<td><?php echo $c['CreatedBy']; ?></td>
						<td><?php echo $c['ModifiedDate']; ?></td>
						<td><?php echo $c['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('casetimeline/edit/'.$c['idCaseTimelines']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('casetimeline/remove/'.$c['idCaseTimelines']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
