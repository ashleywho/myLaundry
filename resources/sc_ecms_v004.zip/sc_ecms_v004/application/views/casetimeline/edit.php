<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Casetimeline Edit</h3>
            </div>
			<?php echo form_open('casetimeline/edit/'.$casetimeline['idCaseTimelines']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="idCase" class="control-label">Cases</label>
						<div class="form-group">
							<select name="idCase" class="form-control">
								<option value="">select cases</option>
								<?php 
								foreach($all_cases as $cases)
								{
									$selected = ($cases['idCase'] == $casetimeline['idCase']) ? ' selected="selected"' : "";

									echo '<option value="'.$cases['idCase'].'" '.$selected.'>'.$cases['CaseName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseTimelineIsDeleted" class="control-label">CaseTimelineIsDeleted</label>
						<div class="form-group">
							<input type="text" name="CaseTimelineIsDeleted" value="<?php echo ($this->input->post('CaseTimelineIsDeleted') ? $this->input->post('CaseTimelineIsDeleted') : $casetimeline['CaseTimelineIsDeleted']); ?>" class="has-datetimepicker form-control" id="CaseTimelineIsDeleted" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseTimelineStatus" class="control-label">CaseTimelineStatus</label>
						<div class="form-group">
							<input type="text" name="CaseTimelineStatus" value="<?php echo ($this->input->post('CaseTimelineStatus') ? $this->input->post('CaseTimelineStatus') : $casetimeline['CaseTimelineStatus']); ?>" class="form-control" id="CaseTimelineStatus" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseTimelineDescription" class="control-label">CaseTimelineDescription</label>
						<div class="form-group">
							<input type="text" name="CaseTimelineDescription" value="<?php echo ($this->input->post('CaseTimelineDescription') ? $this->input->post('CaseTimelineDescription') : $casetimeline['CaseTimelineDescription']); ?>" class="form-control" id="CaseTimelineDescription" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseTimelineRemarks" class="control-label">CaseTimelineRemarks</label>
						<div class="form-group">
							<input type="text" name="CaseTimelineRemarks" value="<?php echo ($this->input->post('CaseTimelineRemarks') ? $this->input->post('CaseTimelineRemarks') : $casetimeline['CaseTimelineRemarks']); ?>" class="form-control" id="CaseTimelineRemarks" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CaseTimelineTag" class="control-label">CaseTimelineTag</label>
						<div class="form-group">
							<input type="text" name="CaseTimelineTag" value="<?php echo ($this->input->post('CaseTimelineTag') ? $this->input->post('CaseTimelineTag') : $casetimeline['CaseTimelineTag']); ?>" class="form-control" id="CaseTimelineTag" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo ($this->input->post('CreatedDate') ? $this->input->post('CreatedDate') : $casetimeline['CreatedDate']); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo ($this->input->post('CreatedBy') ? $this->input->post('CreatedBy') : $casetimeline['CreatedBy']); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo ($this->input->post('ModifiedDate') ? $this->input->post('ModifiedDate') : $casetimeline['ModifiedDate']); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo ($this->input->post('ModifiedBy') ? $this->input->post('ModifiedBy') : $casetimeline['ModifiedBy']); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>