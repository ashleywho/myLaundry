<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Rolepermission Add</h3>
            </div>
            <?php echo form_open('rolepermission/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="idRole" class="control-label">Role</label>
						<div class="form-group">
							<select name="idRole" class="form-control">
								<option value="">select role</option>
								<?php 
								foreach($all_roles as $role)
								{
									$selected = ($role['idRole'] == $this->input->post('idRole')) ? ' selected="selected"' : "";

									echo '<option value="'.$role['idRole'].'" '.$selected.'>'.$role['RoleName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="idPermission" class="control-label">Permission</label>
						<div class="form-group">
							<select name="idPermission" class="form-control">
								<option value="">select permission</option>
								<?php 
								foreach($all_permissions as $permission)
								{
									$selected = ($permission['idPermission'] == $this->input->post('idPermission')) ? ' selected="selected"' : "";

									echo '<option value="'.$permission['idPermission'].'" '.$selected.'>'.$permission['PermissionName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>