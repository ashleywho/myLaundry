<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Teams Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('team/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdTeam</th>
						<th>TeamName</th>
						<th>TeamType</th>
						<th>TeamLeader</th>
						<th>TeamVLeader</th>
						<th>TeamStatus</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($teams as $t){ ?>
                    <tr>
						<td><?php echo $t['idTeam']; ?></td>
						<td><?php echo $t['TeamName']; ?></td>
						<td><?php echo $t['TeamType']; ?></td>
						<td><?php echo $t['TeamLeader']; ?></td>
						<td><?php echo $t['TeamVLeader']; ?></td>
						<td><?php echo $t['TeamStatus']; ?></td>
						<td><?php echo $t['CreatedDate']; ?></td>
						<td><?php echo $t['CreatedBy']; ?></td>
						<td><?php echo $t['ModifiedDate']; ?></td>
						<td><?php echo $t['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('team/edit/'.$t['idTeam']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('team/remove/'.$t['idTeam']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
