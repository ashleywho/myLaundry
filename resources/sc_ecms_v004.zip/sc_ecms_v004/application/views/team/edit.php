<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Team Edit</h3>
            </div>
			<?php echo form_open('team/edit/'.$team['idTeam']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="TeamName" class="control-label">TeamName</label>
						<div class="form-group">
							<input type="text" name="TeamName" value="<?php echo ($this->input->post('TeamName') ? $this->input->post('TeamName') : $team['TeamName']); ?>" class="form-control" id="TeamName" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TeamType" class="control-label">TeamType</label>
						<div class="form-group">
							<input type="text" name="TeamType" value="<?php echo ($this->input->post('TeamType') ? $this->input->post('TeamType') : $team['TeamType']); ?>" class="form-control" id="TeamType" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TeamLeader" class="control-label">TeamLeader</label>
						<div class="form-group">
							<input type="text" name="TeamLeader" value="<?php echo ($this->input->post('TeamLeader') ? $this->input->post('TeamLeader') : $team['TeamLeader']); ?>" class="form-control" id="TeamLeader" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TeamVLeader" class="control-label">TeamVLeader</label>
						<div class="form-group">
							<input type="text" name="TeamVLeader" value="<?php echo ($this->input->post('TeamVLeader') ? $this->input->post('TeamVLeader') : $team['TeamVLeader']); ?>" class="form-control" id="TeamVLeader" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="TeamStatus" class="control-label">TeamStatus</label>
						<div class="form-group">
							<input type="text" name="TeamStatus" value="<?php echo ($this->input->post('TeamStatus') ? $this->input->post('TeamStatus') : $team['TeamStatus']); ?>" class="form-control" id="TeamStatus" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo ($this->input->post('CreatedDate') ? $this->input->post('CreatedDate') : $team['CreatedDate']); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo ($this->input->post('CreatedBy') ? $this->input->post('CreatedBy') : $team['CreatedBy']); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo ($this->input->post('ModifiedDate') ? $this->input->post('ModifiedDate') : $team['ModifiedDate']); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo ($this->input->post('ModifiedBy') ? $this->input->post('ModifiedBy') : $team['ModifiedBy']); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>