<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Users Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('user/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdUser</th>
						<th>Username</th>
						<th>UserPassword</th>
						<th>UserIsLDAP</th>
						<th>UserEmail</th>
						<th>UserIsActive</th>
						<th>UserIsDeleted</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($users as $u){ ?>
                    <tr>
						<td><?php echo $u['idUser']; ?></td>
						<td><?php echo $u['Username']; ?></td>
						<td><?php echo $u['UserPassword']; ?></td>
						<td><?php echo $u['UserIsLDAP']; ?></td>
						<td><?php echo $u['UserEmail']; ?></td>
						<td><?php echo $u['UserIsActive']; ?></td>
						<td><?php echo $u['UserIsDeleted']; ?></td>
						<td><?php echo $u['CreatedDate']; ?></td>
						<td><?php echo $u['CreatedBy']; ?></td>
						<td><?php echo $u['ModifiedDate']; ?></td>
						<td><?php echo $u['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('user/edit/'.$u['idUser']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('user/remove/'.$u['idUser']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
