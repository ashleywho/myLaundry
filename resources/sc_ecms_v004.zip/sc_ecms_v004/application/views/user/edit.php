<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">User Edit</h3>
            </div>
			<?php echo form_open('user/edit/'.$user['idUser']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="Username" class="control-label">Username</label>
						<div class="form-group">
							<input type="text" name="Username" value="<?php echo ($this->input->post('Username') ? $this->input->post('Username') : $user['Username']); ?>" class="form-control" id="Username" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="UserPassword" class="control-label">UserPassword</label>
						<div class="form-group">
							<input type="text" name="UserPassword" value="<?php echo ($this->input->post('UserPassword') ? $this->input->post('UserPassword') : $user['UserPassword']); ?>" class="form-control" id="UserPassword" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="UserIsLDAP" class="control-label">UserIsLDAP</label>
						<div class="form-group">
							<input type="text" name="UserIsLDAP" value="<?php echo ($this->input->post('UserIsLDAP') ? $this->input->post('UserIsLDAP') : $user['UserIsLDAP']); ?>" class="form-control" id="UserIsLDAP" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="UserEmail" class="control-label">UserEmail</label>
						<div class="form-group">
							<input type="text" name="UserEmail" value="<?php echo ($this->input->post('UserEmail') ? $this->input->post('UserEmail') : $user['UserEmail']); ?>" class="form-control" id="UserEmail" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="UserIsActive" class="control-label">UserIsActive</label>
						<div class="form-group">
							<input type="text" name="UserIsActive" value="<?php echo ($this->input->post('UserIsActive') ? $this->input->post('UserIsActive') : $user['UserIsActive']); ?>" class="has-datetimepicker form-control" id="UserIsActive" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="UserIsDeleted" class="control-label">UserIsDeleted</label>
						<div class="form-group">
							<input type="text" name="UserIsDeleted" value="<?php echo ($this->input->post('UserIsDeleted') ? $this->input->post('UserIsDeleted') : $user['UserIsDeleted']); ?>" class="has-datetimepicker form-control" id="UserIsDeleted" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo ($this->input->post('CreatedDate') ? $this->input->post('CreatedDate') : $user['CreatedDate']); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo ($this->input->post('CreatedBy') ? $this->input->post('CreatedBy') : $user['CreatedBy']); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo ($this->input->post('ModifiedDate') ? $this->input->post('ModifiedDate') : $user['ModifiedDate']); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo ($this->input->post('ModifiedBy') ? $this->input->post('ModifiedBy') : $user['ModifiedBy']); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>