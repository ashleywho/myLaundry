<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Casecategory Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('casecategory/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>CaseCategory Id</th>
						<th>CaseCategoryName</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($casecategory as $c){ ?>
                    <tr>
						<td><?php echo $c['CaseCategory_id']; ?></td>
						<td><?php echo $c['CaseCategoryName']; ?></td>
						<td><?php echo $c['CreatedDate']; ?></td>
						<td><?php echo $c['CreatedBy']; ?></td>
						<td><?php echo $c['ModifiedDate']; ?></td>
						<td><?php echo $c['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('casecategory/edit/'.$c['CaseCategory_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('casecategory/remove/'.$c['CaseCategory_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
