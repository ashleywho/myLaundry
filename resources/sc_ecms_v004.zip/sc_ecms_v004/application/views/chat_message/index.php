<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Chat Messages Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('chat_message/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Chat Messages Id</th>
						<th>Sender Id</th>
						<th>Receiver Id</th>
						<th>Chat Messages Status</th>
						<th>Chat Messages Datetime</th>
						<th>Chat Messages Text</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($chat_messages as $c){ ?>
                    <tr>
						<td><?php echo $c['chat_messages_id']; ?></td>
						<td><?php echo $c['sender_id']; ?></td>
						<td><?php echo $c['receiver_id']; ?></td>
						<td><?php echo $c['chat_messages_status']; ?></td>
						<td><?php echo $c['chat_messages_datetime']; ?></td>
						<td><?php echo $c['chat_messages_text']; ?></td>
						<td>
                            <a href="<?php echo site_url('chat_message/edit/'.$c['chat_messages_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('chat_message/remove/'.$c['chat_messages_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
