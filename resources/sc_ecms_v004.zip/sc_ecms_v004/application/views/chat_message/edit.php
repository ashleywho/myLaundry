<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Chat Message Edit</h3>
            </div>
			<?php echo form_open('chat_message/edit/'.$chat_message['chat_messages_id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="sender_id" class="control-label">User</label>
						<div class="form-group">
							<select name="sender_id" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $chat_message['sender_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="receiver_id" class="control-label">User</label>
						<div class="form-group">
							<select name="receiver_id" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $chat_message['receiver_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="chat_messages_status" class="control-label">Chat Messages Status</label>
						<div class="form-group">
							<input type="text" name="chat_messages_status" value="<?php echo ($this->input->post('chat_messages_status') ? $this->input->post('chat_messages_status') : $chat_message['chat_messages_status']); ?>" class="form-control" id="chat_messages_status" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="chat_messages_datetime" class="control-label">Chat Messages Datetime</label>
						<div class="form-group">
							<input type="text" name="chat_messages_datetime" value="<?php echo ($this->input->post('chat_messages_datetime') ? $this->input->post('chat_messages_datetime') : $chat_message['chat_messages_datetime']); ?>" class="has-datetimepicker form-control" id="chat_messages_datetime" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="chat_messages_text" class="control-label">Chat Messages Text</label>
						<div class="form-group">
							<textarea name="chat_messages_text" class="form-control" id="chat_messages_text"><?php echo ($this->input->post('chat_messages_text') ? $this->input->post('chat_messages_text') : $chat_message['chat_messages_text']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>