<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Diary Add</h3>
            </div>
            <?php echo form_open('diary/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="idCase" class="control-label">Cases</label>
						<div class="form-group">
							<select name="idCase" class="form-control">
								<option value="">select cases</option>
								<?php 
								foreach($all_cases as $cases)
								{
									$selected = ($cases['idCase'] == $this->input->post('idCase')) ? ' selected="selected"' : "";

									echo '<option value="'.$cases['idCase'].'" '.$selected.'>'.$cases['CaseName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="idUser" class="control-label">User</label>
						<div class="form-group">
							<select name="idUser" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $this->input->post('idUser')) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="isDeleted" class="control-label">IsDeleted</label>
						<div class="form-group">
							<input type="text" name="isDeleted" value="<?php echo $this->input->post('isDeleted'); ?>" class="has-datetimepicker form-control" id="isDeleted" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo $this->input->post('CreatedDate'); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo $this->input->post('CreatedBy'); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo $this->input->post('ModifiedDate'); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo $this->input->post('ModifiedBy'); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>