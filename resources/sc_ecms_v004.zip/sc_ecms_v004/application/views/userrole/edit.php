<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Userrole Edit</h3>
            </div>
			<?php echo form_open('userrole/edit/'.$userrole['idUserRole']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="idUser" class="control-label">User</label>
						<div class="form-group">
							<select name="idUser" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $userrole['idUser']) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="idRole" class="control-label">Role</label>
						<div class="form-group">
							<select name="idRole" class="form-control">
								<option value="">select role</option>
								<?php 
								foreach($all_roles as $role)
								{
									$selected = ($role['idRole'] == $userrole['idRole']) ? ' selected="selected"' : "";

									echo '<option value="'.$role['idRole'].'" '.$selected.'>'.$role['RoleName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>