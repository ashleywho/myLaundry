<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Filingstatu Edit</h3>
            </div>
			<?php echo form_open('filingstatu/edit/'.$filingstatu['idFilingStatus']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="FilingStatusOwner" class="control-label">FilingStatusOwner</label>
						<div class="form-group">
							<input type="text" name="FilingStatusOwner" value="<?php echo ($this->input->post('FilingStatusOwner') ? $this->input->post('FilingStatusOwner') : $filingstatu['FilingStatusOwner']); ?>" class="form-control" id="FilingStatusOwner" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingStatusCurrent" class="control-label">FilingStatusCurrent</label>
						<div class="form-group">
							<input type="text" name="FilingStatusCurrent" value="<?php echo ($this->input->post('FilingStatusCurrent') ? $this->input->post('FilingStatusCurrent') : $filingstatu['FilingStatusCurrent']); ?>" class="form-control" id="FilingStatusCurrent" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingStatusSummary" class="control-label">FilingStatusSummary</label>
						<div class="form-group">
							<input type="text" name="FilingStatusSummary" value="<?php echo ($this->input->post('FilingStatusSummary') ? $this->input->post('FilingStatusSummary') : $filingstatu['FilingStatusSummary']); ?>" class="form-control" id="FilingStatusSummary" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingStatusApproved" class="control-label">FilingStatusApproved</label>
						<div class="form-group">
							<input type="text" name="FilingStatusApproved" value="<?php echo ($this->input->post('FilingStatusApproved') ? $this->input->post('FilingStatusApproved') : $filingstatu['FilingStatusApproved']); ?>" class="form-control" id="FilingStatusApproved" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="FilingStatusRemarks" class="control-label">FilingStatusRemarks</label>
						<div class="form-group">
							<input type="text" name="FilingStatusRemarks" value="<?php echo ($this->input->post('FilingStatusRemarks') ? $this->input->post('FilingStatusRemarks') : $filingstatu['FilingStatusRemarks']); ?>" class="form-control" id="FilingStatusRemarks" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>