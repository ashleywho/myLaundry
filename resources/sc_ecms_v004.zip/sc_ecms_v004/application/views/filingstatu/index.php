<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Filingstatus Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('filingstatu/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdFilingStatus</th>
						<th>FilingStatusOwner</th>
						<th>FilingStatusCurrent</th>
						<th>FilingStatusSummary</th>
						<th>FilingStatusApproved</th>
						<th>FilingStatusRemarks</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($filingstatus as $f){ ?>
                    <tr>
						<td><?php echo $f['idFilingStatus']; ?></td>
						<td><?php echo $f['FilingStatusOwner']; ?></td>
						<td><?php echo $f['FilingStatusCurrent']; ?></td>
						<td><?php echo $f['FilingStatusSummary']; ?></td>
						<td><?php echo $f['FilingStatusApproved']; ?></td>
						<td><?php echo $f['FilingStatusRemarks']; ?></td>
						<td>
                            <a href="<?php echo site_url('filingstatu/edit/'.$f['idFilingStatus']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('filingstatu/remove/'.$f['idFilingStatus']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
