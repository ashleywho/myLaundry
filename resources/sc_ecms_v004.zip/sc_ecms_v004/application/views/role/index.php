<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Roles Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('role/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdRole</th>
						<th>RoleName</th>
						<th>RoleDesc</th>
						<th>RoleIsDeleted</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($roles as $r){ ?>
                    <tr>
						<td><?php echo $r['idRole']; ?></td>
						<td><?php echo $r['RoleName']; ?></td>
						<td><?php echo $r['RoleDesc']; ?></td>
						<td><?php echo $r['RoleIsDeleted']; ?></td>
						<td><?php echo $r['CreatedDate']; ?></td>
						<td><?php echo $r['CreatedBy']; ?></td>
						<td><?php echo $r['ModifiedDate']; ?></td>
						<td><?php echo $r['ModifiedBy']; ?></td>
						<td>
                            <a href="<?php echo site_url('role/edit/'.$r['idRole']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('role/remove/'.$r['idRole']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
