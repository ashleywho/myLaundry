<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Auditlog Add</h3>
            </div>
            <?php echo form_open('auditlog/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="AuditLogUserID" class="control-label">User</label>
						<div class="form-group">
							<select name="AuditLogUserID" class="form-control">
								<option value="">select user</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['idUser'] == $this->input->post('AuditLogUserID')) ? ' selected="selected"' : "";

									echo '<option value="'.$user['idUser'].'" '.$selected.'>'.$user['Username'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="AuditLogObjectID" class="control-label">Module</label>
						<div class="form-group">
							<select name="AuditLogObjectID" class="form-control">
								<option value="">select module</option>
								<?php 
								foreach($all_modules as $module)
								{
									$selected = ($module['idModule'] == $this->input->post('AuditLogObjectID')) ? ' selected="selected"' : "";

									echo '<option value="'.$module['idModule'].'" '.$selected.'>'.$module['ModuleName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="AuditLogEventID" class="control-label">AuditLogEventID</label>
						<div class="form-group">
							<input type="text" name="AuditLogEventID" value="<?php echo $this->input->post('AuditLogEventID'); ?>" class="form-control" id="AuditLogEventID" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="AuditLogDateTime" class="control-label">AuditLogDateTime</label>
						<div class="form-group">
							<input type="text" name="AuditLogDateTime" value="<?php echo $this->input->post('AuditLogDateTime'); ?>" class="has-datetimepicker form-control" id="AuditLogDateTime" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="AuditLogType" class="control-label">AuditLogType</label>
						<div class="form-group">
							<input type="text" name="AuditLogType" value="<?php echo $this->input->post('AuditLogType'); ?>" class="form-control" id="AuditLogType" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedDate" class="control-label">CreatedDate</label>
						<div class="form-group">
							<input type="text" name="CreatedDate" value="<?php echo $this->input->post('CreatedDate'); ?>" class="has-datetimepicker form-control" id="CreatedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="CreatedBy" class="control-label">CreatedBy</label>
						<div class="form-group">
							<input type="text" name="CreatedBy" value="<?php echo $this->input->post('CreatedBy'); ?>" class="form-control" id="CreatedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedDate" class="control-label">ModifiedDate</label>
						<div class="form-group">
							<input type="text" name="ModifiedDate" value="<?php echo $this->input->post('ModifiedDate'); ?>" class="has-datetimepicker form-control" id="ModifiedDate" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ModifiedBy" class="control-label">ModifiedBy</label>
						<div class="form-group">
							<input type="text" name="ModifiedBy" value="<?php echo $this->input->post('ModifiedBy'); ?>" class="form-control" id="ModifiedBy" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="AuditLogDescription" class="control-label">AuditLogDescription</label>
						<div class="form-group">
							<textarea name="AuditLogDescription" class="form-control" id="AuditLogDescription"><?php echo $this->input->post('AuditLogDescription'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>