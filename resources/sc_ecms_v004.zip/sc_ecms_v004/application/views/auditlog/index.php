<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Auditlogs Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('auditlog/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>IdAuditLog</th>
						<th>AuditLogUserID</th>
						<th>AuditLogObjectID</th>
						<th>AuditLogEventID</th>
						<th>AuditLogDateTime</th>
						<th>AuditLogType</th>
						<th>CreatedDate</th>
						<th>CreatedBy</th>
						<th>ModifiedDate</th>
						<th>ModifiedBy</th>
						<th>AuditLogDescription</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($auditlogs as $a){ ?>
                    <tr>
						<td><?php echo $a['idAuditLog']; ?></td>
						<td><?php echo $a['AuditLogUserID']; ?></td>
						<td><?php echo $a['AuditLogObjectID']; ?></td>
						<td><?php echo $a['AuditLogEventID']; ?></td>
						<td><?php echo $a['AuditLogDateTime']; ?></td>
						<td><?php echo $a['AuditLogType']; ?></td>
						<td><?php echo $a['CreatedDate']; ?></td>
						<td><?php echo $a['CreatedBy']; ?></td>
						<td><?php echo $a['ModifiedDate']; ?></td>
						<td><?php echo $a['ModifiedBy']; ?></td>
						<td><?php echo $a['AuditLogDescription']; ?></td>
						<td>
                            <a href="<?php echo site_url('auditlog/edit/'.$a['idAuditLog']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('auditlog/remove/'.$a['idAuditLog']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
