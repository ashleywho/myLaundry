<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Caseoffender Add</h3>
            </div>
            <?php echo form_open('caseoffender/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="idCase" class="control-label">Cases</label>
						<div class="form-group">
							<select name="idCase" class="form-control">
								<option value="">select cases</option>
								<?php 
								foreach($all_cases as $cases)
								{
									$selected = ($cases['idCase'] == $this->input->post('idCase')) ? ' selected="selected"' : "";

									echo '<option value="'.$cases['idCase'].'" '.$selected.'>'.$cases['CaseName'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="idFilingoffender" class="control-label">IdFilingoffender</label>
						<div class="form-group">
							<input type="text" name="idFilingoffender" value="<?php echo $this->input->post('idFilingoffender'); ?>" class="form-control" id="idFilingoffender" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>